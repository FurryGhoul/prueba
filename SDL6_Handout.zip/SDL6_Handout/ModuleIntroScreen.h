#ifndef __MODULEINTROSCREEN__
#define __MODULEINTROESCREEN__

#include "Module.h"

class ModuleIntroScreen : public Module
{
public:
	ModuleIntroScreen();
	~ModuleIntroScreen();

	bool Start();
	update_status Update();
	bool CleanUp();

public:
	SDL_Texture* intro = nullptr;

};


#endif