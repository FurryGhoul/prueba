#include "Globals.h"
#include "Application.h"
#include "ModuleTextures.h"
#include "ModuleRender.h"
#include "ModulePlayer.h"
#include "ModuleIntroScreen.h"
#include "ModuleInput.h"
#include "ModuleFadeToBlack.h"
#include "ModuleSceneSpace.h"

ModuleIntroScreen::ModuleIntroScreen() : Module()
{

}
ModuleIntroScreen::~ModuleIntroScreen()
{

}

bool ModuleIntroScreen::Start()
{
	LOG("Loading intro screen");

	intro = App->textures->Load("rtype/intro.png");

	App->player->Disable();
	App->scene_space->Disable();

	return true;
}

update_status ModuleIntroScreen::Update()
{

	App->render->Blit(intro, 0, 0, NULL);
	if (App->input->keyboard[SDL_SCANCODE_F])
	{
		App->fade->FadeToBlack(this, App->scene_space, 1.0f);
	}
	return UPDATE_CONTINUE;
}

bool ModuleIntroScreen::CleanUp()
{
	LOG("Unloading space scene");

	App->textures->Unload(intro);
	App->player->Enable();

	return true;
}